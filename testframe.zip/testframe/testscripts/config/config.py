# _*_ coding: utf-8 _*_
'''
    @Author: zhaoxiang.zheng
    @Date: 2018-12-18 18:07:48
    @Last Modified by:   zhaoxiang.zheng
    @Last Modified time: 2018-12-18 18:07:48
'''
import os
import configparser

class Config():
    def __init__(self):
        pass
    def log_email_config(self):
        current_dir = os.getcwd()
        cinfig_path = os.path.join(current_dir, r'testscripts\config\config.ini')
        config = configparser.ConfigParser()
        config.read(cinfig_path)
        
        email_dict = dict()
        email_dict['from_addr'] = config.get('email', 'from_addr')
        email_dict['from_pwd'] = config.get('email', 'from_pwd')
        email_dict['to_addr'] = config.get('email', 'to_addr')
        email_dict['smtp_server'] = config.get('email', 'smtp_server')
        email_dict['smtp_port'] = config.get('email', 'smtp_port')
        return email_dict

if __name__ == "__main__":
    Config().log_email_config()