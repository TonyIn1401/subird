# _*_ coding: utf-8 _*_
'''
    @Author: zhaoxiang.zheng
    @Date: 2018-12-18 10:10:47
    @Last Modified by:   zhaoxiang.zheng
    @Last Modified time: 2018-12-18 10:10:47
'''
import xml.etree.ElementTree as ET
import sys, os
import unittest
from testscripts.common import constant

class TestCaseLoader:
    def exe(self, runner, gen_type):
        module_folder_suites = unittest.TestSuite()

        tree = ET.parse(constant.TESTSUITS_CONFIGFILE_PATH)
        modulefolder = tree.getroot()
        for modules in modulefolder:
            runable = str(modules.get('runable')) == "true"
            module_path = str(modules.get('modulePath')+'.').replace('.', '/')
            #过滤不需要跑的testsuites
            if not runable or (module_path is None):
                print("module floder {0} runable status is {1}".format(module_path, runable))
                continue

            sys.path.append(os.path.dirname(module_path))
            module_suites = unittest.TestSuite()
            for test_cases in modules:
                case_suites = unittest.TestSuite()
                module_name = test_cases.get('moduleName')
                if module_name == None:
                    print('module_name not exists!!')
                    continue
                for test_case in test_cases:
                    test_method = test_case.get("testCaseName")
                    class_name = test_case.get("className")
                    module = __import__(module_name)
                    module_obj = getattr(module, class_name)
                    case_suites.addTest(module_obj(test_method))
                if case_suites.countTestCases == 0:
                    continue
                module_suites.addTests(case_suites)
            if module_suites.countTestCases() == 0:
                continue
            module_folder_suites.addTests(module_suites)
        if (gen_type == constant.GENERATE_XML):
            runner.run_xml(module_folder_suites)
        elif (gen_type == constant.GENERATE_HTML):
            runner.run_html(module_folder_suites)
