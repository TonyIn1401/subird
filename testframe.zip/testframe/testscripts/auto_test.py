# _*_ coding: utf-8 _*_
'''
    @Author: zhaoxiang.zheng
    @Date: 2018-12-18 09:58:54
    @Last Modified by:   zhaoxiang.zheng
    @Last Modified time: 2018-12-18 09:58:54
'''
import os
import time
import logging
import threading
from testscripts.testcase_loader import TestCaseLoader
from testscripts.testcase_runner import TestCaseRunner
from testscripts.common import constant
from testscripts.models.email import Email
from testscripts.notification.email_handler import EmailHandler


class AutoTest(threading.Thread):
    
    def __init__(self, gen_type):
        self.gen_type = gen_type
        super(AutoTest, self).__init__()

    def run(self):
        self.do_test()
        self.send_email()
        

    def do_test(self):
        logging.info("starting test...")
        self.file_name = 'TEST-REPORT-'+time.strftime("%Y%m%d%H%M%S")
        runner = TestCaseRunner(self.file_name)
        TestCaseLoader().exe(runner, self.gen_type)
        logging.info("testing end!")

    def send_email(self):
        email_instance = Email()
        content = self.__get_file_content(self.file_name)
        email_instance.set_body(content, 'html', "测试结果通知")
        email_instance.set_nickname("Python爱好者")
        EmailHandler(email_instance).send()

    def __get_file_content(self, file_name):
        current_dir = os.getcwd()
        file_path = os.path.join(current_dir, "testresult\html\\", file_name+'.html')
        f = open(file_path, "r", encoding='utf-8')
        lines = f.readlines()
        content = ''
        for line in lines:
            content += line
        return content

