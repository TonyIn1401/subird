from email import encoders
from email.mime.text import MIMEText
import smtplib

class EmailHandler():
    def __init__(self, email_instance):
        self.email_instance = email_instance
        print(self.email_instance)
        self.init_msg()
        

    def init_msg(self):
        self.msg = MIMEText(self.email_instance.body, self.email_instance.body_type, 'utf-8')
        self.msg['From'] = '{} {}'.format(self.email_instance.nickname, self.email_instance.from_addr)
        self.msg['To'] = str(self.email_instance.to_addr)
        self.msg['Subject'] = self.email_instance.subject

    def send(self):
        server = smtplib.SMTP(self.email_instance.smtp_server, int(self.email_instance.smtp_port))
        server.set_debuglevel(1)
        server.login(self.email_instance.from_addr, self.email_instance.from_pwd)
        server.sendmail(self.email_instance.from_addr, self.email_instance.to_addr.split(','), self.msg.as_string())
        server.quit()