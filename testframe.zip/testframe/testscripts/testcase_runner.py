# _*_ coding: utf-8 _*_
'''
    @Author: zhaoxiang.zheng
    @Date: 2018-12-18 10:21:07
    @Last Modified by:   zhaoxiang.zheng
    @Last Modified time: 2018-12-18 10:21:07
'''
import os
import time
import xmlrunner
import unittest
from HtmlTestRunner import HTMLTestRunner
from testscripts.common import HTMLTestReportCN
from testscripts.common import constant

class TestCaseRunner:
    def __init__(self, file_name):
        self.file_name = file_name

    def run_xml(self, test_suites):
        file_name = self.file_name +'.xml'
        report_path = os.path.join(constant.RESULT_OUTPUT_PATH_XML, file_name)
        report_io = open(report_path, 'w')
        xml_runner = xmlrunner.XMLTestRunner(output=report_io)
        xml_runner.run(test_suites)

    def run_html(self, test_suites):
        file_name = self.file_name +'.html'
        report_path = os.path.join(constant.RESULT_OUTPUT_PATH_HTML, file_name)
        report_io = open(report_path, 'wb')
        html_runner = HTMLTestReportCN.HTMLTestRunner(stream=report_io, title='自动化测试报告', tester='Yang Ling')
        html_runner.run(test_suites)
        