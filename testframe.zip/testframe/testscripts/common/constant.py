# _*_ coding: utf-8 _*_
'''
    @Author: zhaoxiang.zheng
    @Date: 2018-12-18 09:49:41
    @Last Modified by:   zhaoxiang.zheng
    @Last Modified time: 2018-12-18 09:49:41
'''
#测试执行状态-------------------------------------------------------------------
#登录状态成功、失败
LOGIN_STATUS_OK = "0"
LOGIN_STATUS_FAIL = "1"
#测试结果状态成功、失败
TEST_STATUS_T = "1"
TEST_STATUS_F = "0"
#测试文件路径-------------------------------------------------------------------
#截图路径
SCREEN_SHOT_PATH = r"testresult\screenshot"
#测试结果文件路径
RESULT_OUTPUT_PATH_XML = r"testresult\xml"
RESULT_OUTPUT_PATH_HTML = r"testresult\html"
#测试用例配置文件路径
TESTSUITS_CONFIGFILE_PATH = r"testscripts\config\testcase_config.xml"
#测试随机参数
RANDOM_PARAM = "randomNum"
#导出何种结果
GENERATE_XML = "1"
GENERATE_HTML = "2"
