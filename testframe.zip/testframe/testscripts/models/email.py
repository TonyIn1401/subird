# _*_ coding: utf-8 _*_
'''
    @Author: zhaoxiang.zheng
    @Date: 2018-12-18 17:54:40
    @Last Modified by:   zhaoxiang.zheng
    @Last Modified time: 2018-12-18 17:54:40
'''
from testscripts.config import config
class Email():
    def __init__(self):
        email_dict = config.Config().log_email_config()
        self.from_addr = email_dict['from_addr']
        self.from_pwd = email_dict['from_pwd']
        self.to_addr =  email_dict['to_addr']
        self.smtp_server = email_dict['smtp_server']
        self.smtp_port = email_dict['smtp_port']
        self.nickname = 'Python爱好者'
        self.body = '内容'
        self.body_type = 'plain'
        self.subject = '主题'

    def set_body(self, body, body_type, subject):
        self.body = body
        self.body_type = body_type
        self.subject = subject
    
    def set_nickname(self, nickname):
        self.nickname = nickname