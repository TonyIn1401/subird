# _*_ coding: utf-8 _*_
'''
    @Author: zhaoxiang.zheng
    @Date: 2018-12-18 09:57:10
    @Last Modified by:   zhaoxiang.zheng
    @Last Modified time: 2018-12-18 09:57:10
'''
from testscripts.auto_test import AutoTest
from testscripts.common import constant

class Run():
    def __init__(self):
        pass

    def start(self):
        test_thread = AutoTest(constant.GENERATE_HTML)
        test_thread.start()
        test_thread.join()

if __name__ == "__main__":
    Run().start()
